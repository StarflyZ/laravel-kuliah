<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;
use DB;

class TicketsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('tickets')->insert([
            [
                'number' => 1,
                'description' => Str::random(40),
                'reported_by' => Str::random(10),
                'place_id' => 1,
            ],
            [
                'number' => 2,
                'description' => Str::random(40),
                'reported_by' => Str::random(10),
                'place_id' => 2,
            ]
        ]);
    }
}
