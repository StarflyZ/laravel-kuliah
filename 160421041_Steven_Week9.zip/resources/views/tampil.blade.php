@extends('layouts.conquer2')
@section('content')
    ini adalah section content
@endsection
